"""
AI Cyber Fraud Early Warning System - Flask Web Application.
An AI-Powered Unified Cyber Fraud Detection Platform.
"""

import os
import json
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from werkzeug.utils import secure_filename

# Local modules
import database
from detector.url_detector import analyze_url
from detector.message_detector import analyze_message
from detector.news_detector import analyze_news
from detector.qr_detector import analyze_qr_image, analyze_decoded_payload, ALLOWED_EXTENSIONS
from detector.upi_detector import analyze_upi_indicators
from detector.risk_engine import compute_risk_tier

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "cyber_fraud_warning_system_sec_key_2026")

# Configure upload directory for QR images
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB max upload

# Initialize database tables on startup
database.init_db()


# ==========================================
# CONTEXT PROCESSORS & ERROR HANDLERS
# ==========================================
@app.context_processor
def inject_global_vars():
    """Inject platform metadata into all templates."""
    return {
        "platform_title": "AI Cyber Fraud Early Warning System",
        "platform_subtitle": "Unified AI-Powered Cyber Fraud Detection Platform",
        "current_year": 2026
    }


@app.errorhandler(413)
def request_entity_too_large(error):
    flash("The uploaded file exceeds the 5 MB size limit. Please upload a smaller image.", "danger")
    return redirect(url_for("qr_analysis_page"))


@app.errorhandler(404)
def page_not_found(error):
    return render_template("base.html", error_title="404 - Page Not Found", 
                           error_message="The requested cybersecurity module does not exist."), 404


@app.errorhandler(500)
def server_error(error):
    return render_template("base.html", error_title="500 - Internal Engine Error", 
                           error_message="An unexpected error occurred during security analysis."), 500


# ==========================================
# DASHBOARD & API STATS
# ==========================================
@app.route("/")
def index():
    """Render main security dashboard with analytics, recent history, and module links."""
    stats = database.get_statistics()
    return render_template("index.html", stats=stats, page_name="dashboard")


@app.route("/api/stats")
def api_stats():
    """JSON API providing aggregated metrics for Chart.js rendering."""
    stats = database.get_statistics()
    return jsonify(stats)


# ==========================================
# PHISHING URL DETECTION
# ==========================================
@app.route("/url", methods=["GET", "POST"])
def url_analysis_page():
    result = None
    url_input = ""

    if request.method == "POST":
        url_input = request.form.get("url", "").strip()
        if not url_input:
            flash("Please enter a website URL to analyze.", "warning")
        else:
            result = analyze_url(url_input)
            # Log to SQLite
            database.save_analysis(
                analysis_type="url",
                target_summary=url_input,
                risk_score=result["risk_score"],
                risk_category=result["risk_category"],
                summary_reason=result["summary_reason"],
                details=result
            )

    return render_template("url_analysis.html", result=result, url_input=url_input, page_name="url")


@app.route("/api/analyze/url", methods=["POST"])
def api_analyze_url():
    data = request.get_json(silent=True) or request.form
    url_input = (data.get("url") or "").strip()
    if not url_input:
        return jsonify({"success": False, "error": "URL parameter is required"}), 400

    result = analyze_url(url_input)
    database.save_analysis(
        analysis_type="url",
        target_summary=url_input,
        risk_score=result["risk_score"],
        risk_category=result["risk_category"],
        summary_reason=result["summary_reason"],
        details=result
    )
    return jsonify(result)


# ==========================================
# SCAM MESSAGE DETECTION
# ==========================================
@app.route("/message", methods=["GET", "POST"])
def message_analysis_page():
    result = None
    message_input = ""

    if request.method == "POST":
        message_input = request.form.get("message", "").strip()
        if not message_input:
            flash("Please paste a text message, email, or SMS to inspect.", "warning")
        else:
            result = analyze_message(message_input)
            database.save_analysis(
                analysis_type="message",
                target_summary=message_input,
                risk_score=result["risk_score"],
                risk_category=result["risk_category"],
                summary_reason=result["summary_reason"],
                details=result
            )

    return render_template("message_analysis.html", result=result, message_input=message_input, page_name="message")


@app.route("/api/analyze/message", methods=["POST"])
def api_analyze_message():
    data = request.get_json(silent=True) or request.form
    message_input = (data.get("message") or "").strip()
    if not message_input:
        return jsonify({"success": False, "error": "Message text is required"}), 400

    result = analyze_message(message_input)
    database.save_analysis(
        analysis_type="message",
        target_summary=message_input,
        risk_score=result["risk_score"],
        risk_category=result["risk_category"],
        summary_reason=result["summary_reason"],
        details=result
    )
    return jsonify(result)


# ==========================================
# FAKE NEWS RISK ANALYSIS
# ==========================================
@app.route("/news", methods=["GET", "POST"])
def news_analysis_page():
    result = None
    news_input = ""

    if request.method == "POST":
        news_input = request.form.get("news", "").strip()
        if not news_input:
            flash("Please enter a news headline, claim, or excerpt to evaluate.", "warning")
        else:
            result = analyze_news(news_input)
            database.save_analysis(
                analysis_type="news",
                target_summary=news_input,
                risk_score=result["risk_score"],
                risk_category=result["risk_category"],
                summary_reason=result["summary_reason"],
                details=result
            )

    return render_template("news_analysis.html", result=result, news_input=news_input, page_name="news")


@app.route("/api/analyze/news", methods=["POST"])
def api_analyze_news():
    data = request.get_json(silent=True) or request.form
    news_input = (data.get("news") or "").strip()
    if not news_input:
        return jsonify({"success": False, "error": "News content is required"}), 400

    result = analyze_news(news_input)
    database.save_analysis(
        analysis_type="news",
        target_summary=news_input,
        risk_score=result["risk_score"],
        risk_category=result["risk_category"],
        summary_reason=result["summary_reason"],
        details=result
    )
    return jsonify(result)


# ==========================================
# QR CODE FRAUD DETECTION
# ==========================================
@app.route("/qr", methods=["GET", "POST"])
def qr_analysis_page():
    result = None

    if request.method == "POST":
        if "qr_file" not in request.files or not request.files["qr_file"].filename:
            # Check if user provided decoded payload directly as manual text
            manual_payload = request.form.get("manual_payload", "").strip()
            if manual_payload:
                result = analyze_decoded_payload(manual_payload)
                result["decoded_text"] = manual_payload
                database.save_analysis(
                    analysis_type="qr",
                    target_summary=f"[Manual QR Text] {manual_payload}",
                    risk_score=result["risk_score"],
                    risk_category=result["risk_category"],
                    summary_reason=result["summary_reason"],
                    details=result
                )
            else:
                flash("Please choose a QR code image to upload or paste a decoded QR payload.", "warning")
        else:
            file = request.files["qr_file"]
            ext = os.path.splitext(file.filename)[1].lower()
            if ext not in ALLOWED_EXTENSIONS:
                flash(f"Invalid file format '{ext}'. Permitted: PNG, JPG, JPEG, WEBP, BMP.", "danger")
            else:
                safe_name = secure_filename(file.filename)
                save_path = os.path.join(app.config["UPLOAD_FOLDER"], safe_name)
                file.save(save_path)

                try:
                    result = analyze_qr_image(save_path)
                    target_str = result.get("decoded_text", safe_name)
                    database.save_analysis(
                        analysis_type="qr",
                        target_summary=f"[QR File: {safe_name}] {target_str}",
                        risk_score=result["risk_score"],
                        risk_category=result["risk_category"],
                        summary_reason=result["summary_reason"],
                        details=result
                    )
                finally:
                    # Clean up uploaded image safely from disk
                    if os.path.exists(save_path):
                        try:
                            os.remove(save_path)
                        except Exception:
                            pass

    return render_template("qr_analysis.html", result=result, page_name="qr")


@app.route("/api/analyze/qr", methods=["POST"])
def api_analyze_qr():
    if "qr_file" in request.files and request.files["qr_file"].filename:
        file = request.files["qr_file"]
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            return jsonify({"success": False, "error": f"Invalid format '{ext}'"}), 400
        safe_name = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], safe_name)
        file.save(save_path)
        try:
            result = analyze_qr_image(save_path)
            database.save_analysis(
                analysis_type="qr",
                target_summary=f"[QR] {result.get('decoded_text', safe_name)}",
                risk_score=result["risk_score"],
                risk_category=result["risk_category"],
                summary_reason=result["summary_reason"],
                details=result
            )
            return jsonify(result)
        finally:
            if os.path.exists(save_path):
                try:
                    os.remove(save_path)
                except Exception:
                    pass

    # Check for direct payload string
    data = request.get_json(silent=True) or request.form
    payload = (data.get("payload") or "").strip()
    if payload:
        result = analyze_decoded_payload(payload)
        database.save_analysis(
            analysis_type="qr",
            target_summary=f"[QR Text] {payload}",
            risk_score=result["risk_score"],
            risk_category=result["risk_category"],
            summary_reason=result["summary_reason"],
            details=result
        )
        return jsonify(result)

    return jsonify({"success": False, "error": "No QR image or payload provided"}), 400


# ==========================================
# UPI FRAUD WARNING ANALYSIS
# ==========================================
@app.route("/upi", methods=["GET", "POST"])
def upi_analysis_page():
    result = None
    form_data = {}

    if request.method == "POST":
        form_data = {
            "pin_to_receive": bool(request.form.get("pin_to_receive")),
            "unexpected_collect": bool(request.form.get("unexpected_collect")),
            "remote_app_requested": bool(request.form.get("remote_app_requested")),
            "immediate_pressure": bool(request.form.get("immediate_pressure")),
            "test_transaction": bool(request.form.get("test_transaction")),
            "buyer_overpayment": bool(request.form.get("buyer_overpayment")),
            "qr_to_receive": bool(request.form.get("qr_to_receive")),
            "scenario_description": request.form.get("scenario_description", "").strip()
        }

        # Check if user at least checked one box or wrote a description
        if not any(form_data.values()):
            flash("Please select at least one observation or describe your payment encounter.", "warning")
        else:
            result = analyze_upi_indicators(form_data)
            database.save_analysis(
                analysis_type="upi",
                target_summary=form_data["scenario_description"] or "UPI Checklist Assessment",
                risk_score=result["risk_score"],
                risk_category=result["risk_category"],
                summary_reason=result["summary_reason"],
                details=result
            )

    return render_template("upi_analysis.html", result=result, form_data=form_data, page_name="upi")


@app.route("/api/analyze/upi", methods=["POST"])
def api_analyze_upi():
    data = request.get_json(silent=True) or request.form
    result = analyze_upi_indicators(data)
    preview = data.get("scenario_description") or "UPI Assessment"
    database.save_analysis(
        analysis_type="upi",
        target_summary=preview,
        risk_score=result["risk_score"],
        risk_category=result["risk_category"],
        summary_reason=result["summary_reason"],
        details=result
    )
    return jsonify(result)


# ==========================================
# ANALYSIS HISTORY & LOGS
# ==========================================
@app.route("/history")
def history_page():
    filter_type = request.args.get("type", "all")
    search_query = request.args.get("q", "").strip()
    records = database.get_history(filter_type=filter_type, search=search_query, limit=150)
    return render_template("history.html", records=records, filter_type=filter_type, 
                           search_query=search_query, page_name="history")


@app.route("/history/delete/<int:record_id>", methods=["POST"])
def delete_history_record(record_id):
    database.delete_record(record_id)
    flash(f"Analysis log #{record_id} successfully deleted.", "info")
    return redirect(url_for("history_page"))


@app.route("/history/clear", methods=["POST"])
def clear_all_history():
    database.clear_all_history()
    flash("All analysis history has been permanently cleared.", "success")
    return redirect(url_for("history_page"))


# ==========================================
# SAFETY & AWARENESS GUIDELINES
# ==========================================
@app.route("/awareness")
def awareness_page():
    return render_template("awareness.html", page_name="awareness")


if __name__ == "__main__":
    # Run locally on port 5000
    app.run(host="127.0.0.1", port=5000, debug=True)
