/**
 * AI Cyber Fraud Early Warning System - Frontend Script
 * Handles Chart.js visualization, interactive demo presets, loading overlays,
 * and client-side UI enhancements.
 */

document.addEventListener("DOMContentLoaded", function () {
  initLoadingIndicators();
  initDashboardCharts();
});

// ==========================================
// LOADING OVERLAY HANDLER
// ==========================================
function initLoadingIndicators() {
  const forms = document.querySelectorAll("form.scan-form");
  const overlay = document.getElementById("loadingOverlay");

  forms.forEach((form) => {
    form.addEventListener("submit", function () {
      if (overlay) {
        overlay.style.display = "flex";
      }
    });
  });
}

function showLoading(msg = "Analyzing cyber threat patterns...") {
  const overlay = document.getElementById("loadingOverlay");
  const textEl = document.getElementById("loadingText");
  if (textEl) textEl.textContent = msg;
  if (overlay) overlay.style.display = "flex";
}

function hideLoading() {
  const overlay = document.getElementById("loadingOverlay");
  if (overlay) overlay.style.display = "none";
}

// ==========================================
// PRESET QUICK LOADERS FOR COLLEGE DEMONSTRATION
// ==========================================
window.fillUrlPreset = function (type) {
  const input = document.getElementById("urlInput");
  if (!input) return;

  if (type === "sbi_phish") {
    input.value = "http://185.220.101.5/sbi-banking/login-verify-account.php?token=xyz";
  } else if (type === "paypal_spoof") {
    input.value = "http://paypal.com@verify-login.secure-account.xyz/update";
  } else if (type === "shortener") {
    input.value = "http://bit.ly/free-reward-claim-2026";
  } else if (type === "safe_gov") {
    input.value = "https://cybercrime.gov.in";
  } else if (type === "safe_google") {
    input.value = "https://www.google.com";
  }
};

window.fillMessagePreset = function (type) {
  const input = document.getElementById("messageInput");
  if (!input) return;

  if (type === "electricity_threat") {
    input.value = "URGENT: Your electricity power will be disconnected tonight at 9:30 PM due to unpaid bill. Call Electricity Officer immediately on 9876543210 to avoid penalty.";
  } else if (type === "bank_kyc_apk") {
    input.value = "Dear SBI Customer, your YONO account is suspended today due to expired KYC. Download official verification app at http://sbi-secure.buzz/app.apk to reactivate immediately.";
  } else if (type === "kbc_lottery") {
    input.value = "Congratulations! You have won Rs 25,00,000 in KBC Lucky Draw Lottery. Send your bank details and pay registration fee Rs 1,500 to claim.";
  } else if (type === "safe_bank_tx") {
    input.value = "Rs 450.00 debited from A/C XX4921 on 12-Oct-26 at Star Cafe via UPI Ref 4291839210. Available balance Rs 14,230. Never share your OTP with anyone. - SBI";
  } else if (type === "safe_personal") {
    input.value = "Hi Rahul, let's meet tomorrow at 10 AM in the college library to discuss our machine learning project presentation.";
  }
};

window.fillNewsPreset = function (type) {
  const input = document.getElementById("newsInput");
  if (!input) return;

  if (type === "clickbait_cure") {
    input.value = "SHOCKING TRUTH EXPOSED! Top scientists discover 100% miracle remedy that doctors are desperately hiding from the public! Share before this article is banned by authorities!!!";
  } else if (type === "emergency_ban") {
    input.value = "BREAKING EMERGENCY: Secret government order leaks! Countrywide total currency ban starting midnight tonight! Forward to all WhatsApp groups immediately before lines go down!";
  } else if (type === "credible_rbi") {
    input.value = "According to an official press release by the Press Information Bureau and Reserve Bank of India, the Monetary Policy Committee kept key policy repo rates unchanged at 6.5%.";
  } else if (type === "credible_who") {
    input.value = "The World Health Organization (WHO) published a peer-reviewed scientific report on public water safety standards in collaborative partnership with international laboratories.";
  }
};

window.fillUpiPreset = function (type) {
  const pinBox = document.getElementById("pin_to_receive");
  const collectBox = document.getElementById("unexpected_collect");
  const remoteBox = document.getElementById("remote_app_requested");
  const pressureBox = document.getElementById("immediate_pressure");
  const testBox = document.getElementById("test_transaction");
  const qrBox = document.getElementById("qr_to_receive");
  const desc = document.getElementById("scenario_description");

  // Reset checkboxes
  [pinBox, collectBox, remoteBox, pressureBox, testBox, qrBox].forEach((b) => {
    if (b) b.checked = false;
  });

  if (type === "olx_pin_scam") {
    if (pinBox) pinBox.checked = true;
    if (qrBox) qrBox.checked = true;
    if (pressureBox) pressureBox.checked = true;
    if (desc) desc.value = "An OLX buyer claimed to be an army officer. He sent me a QR code and told me to scan it and enter my UPI PIN to receive an advance deposit of Rs 8,000 for my furniture.";
  } else if (type === "anydesk_takeover") {
    if (remoteBox) remoteBox.checked = true;
    if (pressureBox) pressureBox.checked = true;
    if (desc) desc.value = "A fake customer care executive claimed my refund was stuck. He instructed me to install AnyDesk and QuickSupport on my mobile phone to authorize the reversal.";
  } else if (type === "unprompted_collect") {
    if (collectBox) collectBox.checked = true;
    if (testBox) testBox.checked = true;
    if (desc) desc.value = "I received a sudden Collect Request of Rs 2,500 on PhonePe from an unknown VPA claiming to be from my bank asking for a test verification.";
  } else if (type === "safe_friend") {
    if (desc) desc.value = "Splitting a restaurant dinner bill with my close college classmate. Verifying their phone number before sending Rs 350.";
  }
};

window.fillQrPreset = function (type) {
  const input = document.getElementById("manual_payload");
  if (!input) return;

  if (type === "upi_payee_scam") {
    input.value = "upi://pay?pa=refundhelpdesk99@ybl&pn=SBI+Refund+Desk&am=5000&cu=INR&tn=Security+Refund";
  } else if (type === "quishing_url") {
    input.value = "http://185.220.101.5/banking-update/login.php";
  } else if (type === "safe_upi") {
    input.value = "upi://pay?pa=storemanager@icici&pn=Campus+Bookstore&cu=INR";
  } else if (type === "safe_web") {
    input.value = "https://cybercrime.gov.in";
  }
};

// ==========================================
// CHART.JS DASHBOARD INITIALIZATION
// ==========================================
function initDashboardCharts() {
  const riskCanvas = document.getElementById("riskDistributionChart");
  const moduleCanvas = document.getElementById("moduleBreakdownChart");

  if (!riskCanvas || !moduleCanvas) return;

  fetch("/api/stats")
    .then((res) => res.json())
    .then((stats) => {
      // 1. Risk Distribution Donut Chart
      const catCounts = stats.category_counts || { Low: 0, Medium: 0, High: 0, Critical: 0 };
      const total = stats.total_analyses || 0;

      // Provide default illustrative values if history is empty
      const lowVal = total === 0 ? 1 : catCounts.Low;
      const medVal = total === 0 ? 1 : catCounts.Medium;
      const highVal = total === 0 ? 1 : catCounts.High;
      const critVal = total === 0 ? 1 : catCounts.Critical;

      new Chart(riskCanvas, {
        type: "doughnut",
        data: {
          labels: ["Low Risk (0-24)", "Medium Risk (25-49)", "High Risk (50-74)", "Critical Risk (75-100)"],
          datasets: [
            {
              data: [lowVal, medVal, highVal, critVal],
              backgroundColor: ["#10b981", "#f59e0b", "#f97316", "#ef4444"],
              borderColor: "#121e42",
              borderWidth: 3,
              hoverOffset: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "bottom",
              labels: {
                color: "#cbd5e1",
                font: { family: "Outfit", size: 12 },
                padding: 15
              }
            },
            tooltip: {
              backgroundColor: "#0d1733",
              titleColor: "#00f0ff",
              bodyColor: "#f1f5f9",
              borderColor: "rgba(56, 189, 248, 0.2)",
              borderWidth: 1
            }
          },
          cutout: "70%"
        }
      });

      // 2. Module Breakdown Bar Chart
      const modCounts = stats.module_counts || { url: 0, message: 0, news: 0, qr: 0, upi: 0 };

      new Chart(moduleCanvas, {
        type: "bar",
        data: {
          labels: ["URLs", "Messages", "News", "QR Codes", "UPI Scams"],
          datasets: [
            {
              label: "Scans Performed",
              data: [
                modCounts.url || 0,
                modCounts.message || 0,
                modCounts.news || 0,
                modCounts.qr || 0,
                modCounts.upi || 0
              ],
              backgroundColor: [
                "rgba(0, 240, 255, 0.65)",
                "rgba(59, 130, 246, 0.65)",
                "rgba(99, 102, 241, 0.65)",
                "rgba(168, 85, 247, 0.65)",
                "rgba(244, 63, 94, 0.65)"
              ],
              borderColor: [
                "#00f0ff",
                "#3b82f6",
                "#6366f1",
                "#a855f7",
                "#f43f5e"
              ],
              borderWidth: 1.5,
              borderRadius: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: { color: "rgba(255, 255, 255, 0.05)" },
              ticks: { color: "#94a3b8", font: { family: "Outfit" } }
            },
            y: {
              beginAtZero: true,
              grid: { color: "rgba(255, 255, 255, 0.05)" },
              ticks: { color: "#94a3b8", font: { family: "Outfit" }, precision: 0 }
            }
          },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: "#0d1733",
              titleColor: "#00f0ff",
              bodyColor: "#f1f5f9",
              borderColor: "rgba(56, 189, 248, 0.2)",
              borderWidth: 1
            }
          }
        }
      });
    })
    .catch((err) => console.error("Error loading dashboard metrics:", err));
}

// Copy to clipboard helper
window.copyToClipboard = function (text, btnElement) {
  navigator.clipboard.writeText(text).then(() => {
    if (btnElement) {
      const originalText = btnElement.innerHTML;
      btnElement.innerHTML = '<i class="fas fa-check text-success"></i> Copied!';
      setTimeout(() => {
        btnElement.innerHTML = originalText;
      }, 2000);
    }
  });
};
