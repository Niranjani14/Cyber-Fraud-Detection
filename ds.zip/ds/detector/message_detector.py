"""
Scam Message and Phishing SMS Detection Module.
Combines machine learning text classification (TF-IDF + Scikit-learn) with
explainable heuristic rule engines to analyze SMS, emails, and chat messages for:
- Urgent coercion and threats
- Credential and OTP harvesting
- Prize, lottery, and job lures
- Financial institution and authority impersonation
- Suspicious links and APK download lures
"""

import re
from typing import Dict, Any, List
from .risk_engine import format_detection_result

# Try importing scikit-learn for trained ML text classification
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.naive_bayes import MultinomialNB
    from sklearn.pipeline import Pipeline
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# Curated training corpus representing representative real-world cyber fraud, phishing, and legitimate messages
TRAINING_SAMPLES = [
    # --- FRAUD / SCAM SAMPLES (Class 1) ---
    ("Dear SBI Customer, your YONO account is blocked today. Please update PAN immediately at http://sbi-kyc-update.xyz to avoid suspension.", 1),
    ("URGENT: Your electricity power will be disconnected tonight at 9:30 PM due to unpaid bill. Call Electricity Officer on 9876543210 immediately.", 1),
    ("Congratulations! You have won Rs 25,00,000 in KBC Lucky Draw Lottery. Send your bank details and pay registration fee Rs 1,500 to claim.", 1),
    ("Dear Customer, Your Netflix subscription expired. Verify payment info at http://netflix-billing-renew.cc or service terminates within 2 hours.", 1),
    ("Earn Rs 3000 to 8000 daily working from home! Simple YouTube like and review tasks. Contact HR Manager on Telegram @JobManager now.", 1),
    ("Your HDFC credit card reward points worth Rs 9,850 are expiring today! Redeem cash now by clicking http://hdfc-rewards-points.top/claim", 1),
    ("Income Tax Refund Notice: You have an approved refund of Rs 24,490. Update bank account number and submit OTP to receive refund.", 1),
    ("FINAL NOTICE: Delhi Police Cyber Crime department has filed FIR against you. Call immediately on 8899001122 or arrest warrant will be issued.", 1),
    ("Dear User, your SIM card will be deactivated within 24 hours as per TRAI guidelines. Click http://trai-sim-verify.cam to submit Aadhaar.", 1),
    ("Alert: Unusual login attempt detected on your PayPal account. If not you, verify identity and enter your password at http://paypal-secure-auth.club", 1),
    ("Investment Opportunity: Guaranteed 400% profit in 7 days with cryptocurrency trading. Deposit Rs 5,000 to get Rs 25,000 back. WhatsApp us.", 1),
    ("Your package cannot be delivered due to incomplete address. Pay redelivery fee of Rs 25 at http://india-post-tracking.live to reschedule.", 1),
    ("Free gift card worth Rs 10000! Spin the wheel to claim your prize now. Enter OTP sent to your phone to confirm your delivery.", 1),
    ("Bank alert: Rs 50,000 debited from your account via UPI. If not done by you, click here immediately to cancel transaction and enter UPI PIN.", 1),
    ("Download our official APK app to complete your bank e-KYC. Click http://secure-apk-download.buzz/bank.apk and install.", 1),
    
    # --- LEGITIMATE / SAFE SAMPLES (Class 0) ---
    ("Your OTP for logging into HDFC Bank NetBanking is 482910. Valid for 5 minutes. Do not share this OTP with anyone, including bank staff.", 0),
    ("Rs 450.00 debited from A/C XX4921 on 12-Oct-26 at Star Cafe via UPI Ref 4291839210. Available balance Rs 14,230. - SBI", 0),
    ("Your Amazon order #402-9182391-2391 has been dispatched and will arrive by tomorrow evening. Track in your Amazon mobile app.", 0),
    ("Hi Rahul, let's meet tomorrow at 10 AM in the college library to discuss our machine learning project presentation.", 0),
    ("Dear Customer, your monthly electricity bill for Sep 2026 is Rs 1,240. Due date is 25-Oct-26. Pay securely via BSES official website or portal.", 0),
    ("Your appointment with Dr. Sharma is confirmed for Thursday at 4:30 PM at City Care Hospital. Please arrive 15 minutes early.", 0),
    ("Swiggy: Your food order from Biryani Blues is on the way! Delivery partner Suresh will arrive in 12 mins. Track order in Swiggy app.", 0),
    ("Your Google verification code is G-938210. Never share this code with anyone.", 0),
    ("Team meeting scheduled for tomorrow at 2 PM to review quarterly performance milestones. Please review agenda doc beforehand.", 0),
    ("Dear subscriber, your recharge of Rs 299 is successful. Valid for 28 days with 1.5GB/day data. Thank you for choosing Jio.", 0),
    ("Happy Birthday Priya! Wishing you a fantastic year ahead filled with joy and success. See you at the dinner party tonight!", 0),
    ("Uber: Your driver Ramesh (Swift Dzire DL 1C AB 1234) is arriving in 3 mins for pickup at Connaught Place.", 0),
    ("Your flight 6E-204 from Delhi to Mumbai is on schedule. Web check-in is now open on the IndiGo official app.", 0),
    ("Library reminder: The book 'Introduction to Algorithms' is due for return on 18th Oct. Renew online via college intranet portal.", 0),
    ("Payment of Rs 1,800 received from Anita via PhonePe. Transaction ID T261013145028. - PhonePe", 0)
]

# Global trained model holder
_MODEL_PIPELINE = None


def get_trained_classifier():
    """Lazily initialize and train the TF-IDF + MultinomialNB text classification pipeline."""
    global _MODEL_PIPELINE
    if not SKLEARN_AVAILABLE:
        return None

    if _MODEL_PIPELINE is None:
        try:
            texts = [x[0] for x in TRAINING_SAMPLES]
            labels = [x[1] for x in TRAINING_SAMPLES]

            pipeline = Pipeline([
                ('tfidf', TfidfVectorizer(ngram_range=(1, 2), stop_words='english', lowercase=True)),
                ('clf', MultinomialNB(alpha=0.1))
            ])
            pipeline.fit(texts, labels)
            _MODEL_PIPELINE = pipeline
        except Exception:
            _MODEL_PIPELINE = None

    return _MODEL_PIPELINE


# Heuristic rule patterns
URGENCY_PATTERNS = [
    r'\b(urgent|urgently|immediate|immediately|action required|within \d+ hours?|tonight|today only)\b',
    r'\b(blocked|suspended|terminated|deactivated|expire|expiring|cut off|disconnected)\b',
    r'\b(fir|police|arrest|court|legal action|warrant|complaint|penalty|fine)\b'
]

CREDENTIAL_PATTERNS = [
    r'\b(otp|one time password|pin|upi pin|password|cvv|expiry date|card number)\b',
    r'\b(aadhaar|pan card|pan number|bank details|account number|credentials)\b',
    r'\b(share (your )?otp|enter (your )?pin|send (your )?password|submit credentials)\b'
]

LURE_PATTERNS = [
    r'\b(congratulations|congrats|lucky draw|lottery|winner|won rs|won \$|crore|lakh)\b',
    r'\b(work from home|part time job|earn \d+ daily|telegram|earn money|youtube likes?)\b',
    r'\b(free gift|reward points?|cashback|claim prize|bonus|guaranteed return|guaranteed profit)\b',
    r'\b(income tax refund|tax refund approved|refund credited)\b'
]

IMPERSONATION_PATTERNS = [
    r'\b(sbi|hdfc|icici|axis bank|paytm|phonepe|gpay|yono|pnb|bob)\b',
    r'\b(trai|electricity officer|bses|dhbvn|delhi police|cyber crime|income tax department)\b',
    r'\b(netflix|amazon|india post|courier delivery|fedex|dhl)\b'
]

APK_LINK_PATTERNS = [
    r'\.apk\b',
    r'https?://[^\s]+',
    r'\b(download app|install application|click here|visit link)\b'
]


def analyze_message(text: str) -> Dict[str, Any]:
    """
    Analyze text message using dual evaluation:
    1. Machine learning text classification (TF-IDF + Naive Bayes)
    2. Deep heuristic rule evaluation for specific fraud tactics
    """
    if not text or not isinstance(text, str):
        return format_detection_result(
            module_type="message",
            raw_score=0,
            indicators=[],
            recommendations=["Paste a message to begin analysis."],
            input_preview="Empty Input",
            disclaimer="No message content was provided."
        )

    clean_text = text.strip()
    score = 0
    indicators: List[Dict[str, str]] = []
    recommendations: List[str] = []

    # 1. Machine Learning Text Classification
    ml_confidence = 0.0
    ml_used = False
    clf = get_trained_classifier()

    if clf is not None:
        try:
            proba = clf.predict_proba([clean_text])[0]
            ml_confidence = float(proba[1])  # Probability of scam
            ml_used = True
            
            # Map ML confidence to base score
            ml_score_contribution = int(ml_confidence * 45)
            score += ml_score_contribution

            if ml_confidence >= 0.70:
                indicators.append({
                    "title": f"AI Text Classifier: High Scam Similarity ({int(ml_confidence*100)}%)",
                    "severity": "high",
                    "description": "Trained TF-IDF model matched message phrasing with high-confidence fraud and phishing patterns.",
                    "why_it_matters": "NLP model identified recurring semantic structures, vocabulary distributions, and manipulative phrasing typical of known scams."
                })
            elif ml_confidence <= 0.25:
                indicators.append({
                    "title": f"AI Text Classifier: Low Scam Similarity ({int((1-ml_confidence)*100)}% Legitimate)",
                    "severity": "low",
                    "description": "Message structure aligns with standard transactional, personal, or administrative communications.",
                    "why_it_matters": "The phrasing lacks aggressive scam markers and fits common conversational/notification formats."
                })
        except Exception:
            ml_used = False

    # 2. Heuristic Rules & Threat Pattern Extraction
    lower_text = clean_text.lower()

    # Rule A: Urgency and Coercion
    urgency_matches = []
    for pat in URGENCY_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            urgency_matches.extend(matches)
    
    if urgency_matches:
        score += 25
        found_kw = list(set([m if isinstance(m, str) else m[0] for m in urgency_matches]))
        indicators.append({
            "title": f"Psychological Urgency & Fear Tactics ({', '.join(found_kw[:3])})",
            "severity": "high",
            "description": f"Detected urgency/threat phrases: {', '.join(found_kw)}.",
            "why_it_matters": "Scammers create artificial urgency (e.g. 'electricity cut off in 2 hours', 'account suspended today') to panic victims so they act impulsively without verifying with official sources."
        })

    # Rule B: Credential & OTP Harvesting Requests
    cred_matches = []
    for pat in CREDENTIAL_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            cred_matches.extend(matches)
    
    if cred_matches:
        # Check if it's an official warning ("Do not share OTP")
        is_warning_context = bool(re.search(r'\b(do not share|never share|will never ask)\b', lower_text))
        if is_warning_context:
            indicators.append({
                "title": "Standard Bank Security Disclaimer",
                "severity": "low",
                "description": "The message advises the user never to share OTPs or passwords.",
                "why_it_matters": "Legitimate banks include standard cautionary disclaimers. Verify that this message was not sent alongside a fake link."
            })
        else:
            score += 35
            found_kw = list(set([m if isinstance(m, str) else m[0] for m in cred_matches]))
            indicators.append({
                "title": "Credential & Sensitive Data Request",
                "severity": "critical",
                "description": f"The message solicits or references credentials/PII: {', '.join(found_kw)}.",
                "why_it_matters": "Legitimate organizations NEVER ask you to disclose OTPs, PINs, or CVVs via SMS or chat. Any message requesting your OTP or PIN is an active cyber theft attempt."
            })

    # Rule C: Lottery, Work-from-Home, or Prize Lures
    lure_matches = []
    for pat in LURE_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            lure_matches.extend(matches)
    
    if lure_matches:
        score += 30
        found_kw = list(set([m if isinstance(m, str) else m[0] for m in lure_matches]))
        indicators.append({
            "title": f"Unsolicited Prize / Job / Financial Lure",
            "severity": "high",
            "description": f"The text contains financial attraction hooks: {', '.join(found_kw)}.",
            "why_it_matters": "Advance-fee fraud, fake Telegram part-time job scams, and fake lottery schemes lure victims with promises of high profits before demanding 'advance processing fees'."
        })

    # Rule D: Brand / Authority Impersonation
    imp_matches = []
    for pat in IMPERSONATION_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            imp_matches.extend(matches)
    
    if imp_matches and (urgency_matches or lure_matches or cred_matches):
        score += 20
        found_kw = list(set([m if isinstance(m, str) else m[0] for m in imp_matches]))
        indicators.append({
            "title": f"High-Trust Brand Impersonation ({', '.join(found_kw[:2])})",
            "severity": "high",
            "description": f"Mentions well-known brand or authority: {', '.join(found_kw)} alongside suspicious demands.",
            "why_it_matters": "Cybercriminals exploit public trust in established banks, utilities, and tax agencies to disarm skepticism."
        })

    # Rule E: Embedded Links or Malicious APK Mentions
    urls = re.findall(r'https?://[^\s]+', clean_text)
    has_apk = bool(re.search(r'\.apk\b', lower_text))
    if has_apk:
        score += 40
        indicators.append({
            "title": "Malicious Android Package (.APK) Lure",
            "severity": "critical",
            "description": "The message promotes installing an external .APK file.",
            "why_it_matters": "Attackers distribute trojanized APK apps masquerading as bank updates or electricity portals. These apps steal SMS OTPs and control the victim's device."
        })
    elif urls:
        score += 20
        indicators.append({
            "title": f"Embedded Hyperlink Present ({urls[0][:40]}...)",
            "severity": "medium",
            "description": "Message directs the reader to an external web address.",
            "why_it_matters": "SMS phishing ('Smishing') relies heavily on embedded links to direct victims to counterfeit cloned portals."
        })

    # Recommendations based on evaluation
    if score >= 75:
        recommendations.extend([
            "NEVER click links or dial phone numbers specified in this message.",
            "NEVER share your OTP, PIN, password, or banking information.",
            "Block the sender number and report as spam.",
            "If your bank was mentioned, check your official mobile banking app independently or contact your branch directly."
        ])
    elif score >= 50:
        recommendations.extend([
            "Treat this message with high skepticism.",
            "Do not rush to respond despite any stated deadline or threat.",
            "Verify any claims by checking official customer service numbers from your statement or card."
        ])
    elif score >= 25:
        recommendations.extend([
            "Review sender information and cross-reference with official records.",
            "Never forward unverified promotional messages to friends or family.",
            "Ensure you do not enter credentials on third-party links."
        ])
    else:
        recommendations.extend([
            "This message displays characteristics of a standard notification.",
            "Always safeguard your OTP and PIN — legitimate staff will never ask for them.",
            "Keep your banking and telecom apps updated."
        ])

    engine_tag = "TF-IDF + Scikit-Learn ML Model & Heuristic Engine" if ml_used else "Heuristic Rule-Based Pattern Engine"

    technical_details = {
        "detection_engine": engine_tag,
        "ml_scam_confidence": f"{int(ml_confidence*100)}%" if ml_used else "N/A (Rule Engine Mode)",
        "char_count": len(clean_text),
        "embedded_links_count": len(urls),
        "has_apk_file": has_apk
    }

    return format_detection_result(
        module_type="message",
        raw_score=score,
        indicators=indicators,
        recommendations=recommendations,
        input_preview=clean_text[:100],
        technical_details=technical_details
    )
