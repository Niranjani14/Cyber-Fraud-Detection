"""
News Content and Misinformation Risk Analysis Module.
Analyzes news headlines, viral forwards, and social media claims for:
- Sensationalism, clickbait, and emotionally manipulative framing
- Source attribution hygiene (verified press vs. anonymous rumors)
- Unsubstantiated extraordinary claims (medical miracles, emergency decrees)
- Linguistic markers of viral disinformation

IMPORTANT ADVISORY:
This module evaluates stylistic and attribution indicators that signify content
requiring independent journalistic verification. It does NOT assert definitive factual
truth or falsehood without authoritative third-party fact-checking.
"""

import re
from typing import Dict, Any, List
from .risk_engine import format_detection_result


# Curated patterns for sensationalist, clickbait, and manipulative language
SENSATIONAL_PATTERNS = [
    r'\b(shocking|unbelievable|miracle|secret revealed|exposed|they don\'t want you to know)\b',
    r'\b(mind blowing|you won\'t believe|cure doctors hate|banned by authorities|conspiracy)\b',
    r'\b(breaking emergency|urgent alert|share before deleted|must watch before removed)\b',
    r'\b(100% guaranteed cure|magic remedy|miracle herb|overnight transformation)\b',
    r'\b(government secretly announced|immediate countrywide ban|currency banned again)\b'
]

# Patterns representing vague or anonymous attribution
VAGUE_SOURCE_PATTERNS = [
    r'\b(sources say|insiders reveal|anonymous source|it is claimed that|people are saying)\b',
    r'\b(forwarded as received|viral message|whatsapp forward|as seen on internet)\b',
    r'\b(top scientists say|unnamed experts|unspecified doctors|secret report claims)\b'
]

# Reputable journalism, official state or peer-reviewed citations
CREDIBLE_ATTRIBUTION_PATTERNS = [
    r'\b(reuters|associated press|bbc|pib fact check|press information bureau|who|rbi)\b',
    r'\b(ministry of|supreme court|official gazette|peer-reviewed|published in nature|the lancet)\b',
    r'\b(spokesperson stated|press release dated|official bulletin|statement issued by)\b'
]


def analyze_news(text: str) -> Dict[str, Any]:
    """
    Evaluates news text or claim for sensationalism, linguistic manipulation,
    and missing attribution flags.
    """
    if not text or not isinstance(text, str):
        return format_detection_result(
            module_type="news",
            raw_score=0,
            indicators=[],
            recommendations=["Enter a news headline, claim, or excerpt to evaluate."],
            input_preview="Empty Input",
            disclaimer="No text was provided for news analysis."
        )

    clean_text = text.strip()
    score = 0
    indicators: List[Dict[str, str]] = []
    recommendations: List[str] = []

    lower_text = clean_text.lower()

    # 1. Formatting & Punctuation Anomalies (ALL CAPS, Excessive Punctuation)
    words = clean_text.split()
    caps_words = [w for w in words if w.isupper() and len(w) > 2 and w.isalpha()]
    caps_ratio = len(caps_words) / max(1, len(words))

    exclamation_count = clean_text.count("!")
    question_count = clean_text.count("?")

    if caps_ratio > 0.35 and len(words) >= 4:
        score += 20
        indicators.append({
            "title": f"Excessive Uppercase Shouting ({int(caps_ratio*100)}% capitalized)",
            "severity": "medium",
            "description": f"Significant portion of words are fully capitalized: {', '.join(caps_words[:4])}...",
            "why_it_matters": "Mainstream journalistic standards strictly avoid capitalization shouting. Disinformation and sensationalist clickbait frequently utilize all-caps to invoke urgency or panic."
        })

    if exclamation_count >= 3 or "!?" in clean_text or "?!" in clean_text:
        score += 15
        indicators.append({
            "title": f"Emotional Punctuation Density ({exclamation_count} exclamation marks)",
            "severity": "medium",
            "description": "Heavy use of dramatic exclamation points or stacked '?!' marks.",
            "why_it_matters": "Objective reportage relies on factual exposition rather than hyper-punctuated emotional stimuli."
        })

    # 2. Sensationalist and Manipulative Phrasing
    sensational_hits = []
    for pat in SENSATIONAL_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            sensational_hits.extend(matches)

    if sensational_hits:
        found_kw = list(set([h if isinstance(h, str) else h[0] for h in sensational_hits]))
        score += min(35, len(found_kw) * 15)
        indicators.append({
            "title": f"Sensationalist & Clickbait Phrasing ({', '.join(found_kw[:3])})",
            "severity": "high",
            "description": f"Contains emotionally manipulative or sensationalist claims: {', '.join(found_kw)}.",
            "why_it_matters": "Headlines designed to provoke outrage, fear, or astonishment are frequently used in viral disinformation campaigns to trigger impulsive resharing without critical verification."
        })

    # 3. Source Attribution & Citation Analysis
    vague_hits = []
    for pat in VAGUE_SOURCE_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            vague_hits.extend(matches)

    if vague_hits:
        found_vague = list(set([v if isinstance(v, str) else v[0] for v in vague_hits]))
        score += 25
        indicators.append({
            "title": "Vague or Anonymous Attribution",
            "severity": "high",
            "description": f"Relies on unverified sourcing phrases: {', '.join(found_vague)}.",
            "why_it_matters": "Legitimate investigative reports name institutions, on-the-record spokespersons, or official documents. Vague 'sources claim' or 'viral forward' phrasing often cloaks unsubstantiated rumors."
        })

    # Check for credible citations to reduce score
    credible_hits = []
    for pat in CREDIBLE_ATTRIBUTION_PATTERNS:
        matches = re.findall(pat, lower_text)
        if matches:
            credible_hits.extend(matches)

    if credible_hits:
        score = max(0, score - 25)
        found_cred = list(set([c if isinstance(c, str) else c[0] for c in credible_hits]))
        indicators.append({
            "title": f"Verifiable Source Citation ({', '.join(found_cred[:2])})",
            "severity": "low",
            "description": f"References recognized institutions or journalistic agencies: {', '.join(found_cred)}.",
            "why_it_matters": "Attribution to established entities allows readers to cross-reference claims directly against published institutional bulletins."
        })
    elif not vague_hits and len(words) > 8:
        score += 15
        indicators.append({
            "title": "Absence of Direct Sourcing",
            "severity": "medium",
            "description": "The excerpt lacks named sources, dates, or official citations.",
            "why_it_matters": "Claims presented without clear origin require verification before being accepted as factual truth."
        })

    # 4. Viral Reshare Pressure
    if re.search(r'\b(forward to everyone|share with all groups|make this viral|forward immediately)\b', lower_text):
        score += 25
        indicators.append({
            "title": "Viral Forwarding Pressure",
            "severity": "high",
            "description": "Explicit call to mass-forward or share across social media groups.",
            "why_it_matters": "Coordinated disinformation networks depend on weaponizing emotional peer-sharing to spread before professional fact-checkers can debunk the claim."
        })

    # Recommendations
    recommendations.extend([
        "Cross-reference this claim with authoritative fact-checking resources (e.g., PIB Fact Check, Reuters Fact Check, Alt News).",
        "Search the exact quote or key names on verified news agencies to check if independent outlets have corroborated the story.",
        "Refrain from forwarding unverified claims in messaging groups until you confirm official press statements."
    ])

    disclaimer = (
        "Educational Fact-Check Notice: This automated analysis evaluates linguistic patterns, "
        "punctuation, emotional framing, and sourcing clarity. It serves as an early indicator that "
        "the claim warrants independent verification. This system does NOT prove an event did not happen "
        "nor does it definitively brand claims as false without verified external evidence."
    )

    technical_details = {
        "analysis_type": "Linguistic & Attribution Heuristics",
        "sensational_flags_count": len(sensational_hits),
        "vague_sources_count": len(vague_hits),
        "credible_sources_count": len(credible_hits),
        "word_count": len(words)
    }

    return format_detection_result(
        module_type="news",
        raw_score=score,
        indicators=indicators,
        recommendations=recommendations,
        input_preview=clean_text[:100],
        technical_details=technical_details,
        disclaimer=disclaimer
    )
