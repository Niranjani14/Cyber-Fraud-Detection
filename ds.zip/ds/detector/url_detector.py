"""
Phishing Website and Suspicious URL Detection Module.
Performs in-depth lexical, syntactic, and structural analysis of URLs:
- Length heuristics
- Protocol security & limitation awareness
- IP address hostnames
- Subdomain deception and brand impersonation
- Obfuscation characters (@, double slashes, hex encoding)
- High-abuse TLDs
- Shortener detection
- Homograph/punycode flags
- Suspicious keyword matching
"""

import re
from urllib.parse import urlparse
from typing import Dict, Any, List
from .risk_engine import format_detection_result


# High-abuse or cheap top-level domains frequently leveraged in phishing campaigns
SUSPICIOUS_TLDS = {
    "xyz", "top", "tk", "ml", "ga", "cf", "gq", "buzz", "cam", "work",
    "icu", "rest", "country", "club", "fit", "surf", "monster", "cfd",
    "sbs", "quest", "click", "link", "zip", "mov"
}

# Known URL shortener services that mask the true target destination
URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "is.gd", "t.co", "cutt.ly", "rb.gy",
    "shorturl.at", "ow.ly", "buff.ly", "goo.gl", "tiny.cc", "rebrand.ly"
}

# Sensitive brand and credential-harvesting tokens
PHISHING_KEYWORDS = [
    "login", "signin", "verify", "verification", "security", "account",
    "banking", "update", "wallet", "kyc", "aadhaar", "pancard", "pan-card",
    "free-gift", "lottery", "bonus", "claim", "reward", "authenticate",
    "recovery", "support", "billing", "invoice", "refund", "suspend",
    "reactivate", "confirm", "passcode", "credit", "debit", "secure-bank"
]

# Trusted high-profile domains for baseline comparison
TRUSTED_DOMAINS = {
    "google.com", "www.google.com", "microsoft.com", "apple.com", "amazon.com",
    "github.com", "gov.in", "nic.in", "rbi.org.in", "wikipedia.org", "paypal.com"
}

# Targeted financial and technology brands often impersonated
TARGETED_BRANDS = [
    "paypal", "sbi", "hdfc", "icici", "axis", "paytm", "phonepe", "gpay",
    "amazon", "apple", "netflix", "microsoft", "google", "facebook", "instagram"
]


def analyze_url(raw_url: str) -> Dict[str, Any]:
    """
    Analyzes an input URL and returns a structured risk evaluation with indicators,
    severity tags, and explainability rationales.
    """
    if not raw_url or not isinstance(raw_url, str):
        return format_detection_result(
            module_type="url",
            raw_score=0,
            indicators=[],
            recommendations=["Enter a valid website address to analyze."],
            input_preview="Empty Input",
            disclaimer="No URL was provided for analysis."
        )

    url = raw_url.strip()

    # Prepend scheme if missing for accurate urlparse parsing
    has_explicit_scheme = bool(re.match(r'^[a-zA-Z]+://', url))
    parsed_candidate = url if has_explicit_scheme else f"http://{url}"

    try:
        parsed = urlparse(parsed_candidate)
        scheme = parsed.scheme.lower()
        hostname = (parsed.hostname or "").lower()
        path = parsed.path or ""
        query = parsed.query or ""
    except Exception as e:
        return format_detection_result(
            module_type="url",
            raw_score=65,
            indicators=[{
                "title": "Malformed URL Syntax",
                "severity": "high",
                "description": f"URL parser failed on string: {str(e)}",
                "why_it_matters": "Malformed or illegible URLs often signify obfuscation attempts or intentional parser confusion."
            }],
            recommendations=["Do not visit this address.", "Verify spelling carefully."],
            input_preview=url[:80]
        )

    score = 0
    indicators: List[Dict[str, str]] = []
    recommendations: List[str] = []

    # 1. Scheme Analysis (HTTPS vs HTTP)
    if scheme == "http":
        score += 20
        indicators.append({
            "title": "Insecure Protocol (HTTP)",
            "severity": "medium",
            "description": "The URL uses unencrypted plain HTTP instead of HTTPS.",
            "why_it_matters": "HTTP sends all traffic unencrypted, making it vulnerable to interception, tampering, and credential theft. However, note that while HTTP is insecure, having HTTPS alone does NOT prove a website is safe."
        })
    elif scheme == "https":
        indicators.append({
            "title": "HTTPS Encryption Present",
            "severity": "low",
            "description": "Traffic is encrypted between your browser and the web server.",
            "why_it_matters": "Encryption protects data in transit. Important reminder: over 80% of modern phishing pages also use free HTTPS certificates, so HTTPS does NOT guarantee organizational legitimacy."
        })
    else:
        score += 30
        indicators.append({
            "title": f"Unusual Protocol ({scheme})",
            "severity": "high",
            "description": f"The URL specifies a non-standard protocol '{scheme}'.",
            "why_it_matters": "Protocols other than HTTP/HTTPS may trigger unexpected application behavior or exploit protocol handlers."
        })

    # 2. IP Address as Hostname
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if re.match(ip_pattern, hostname):
        score += 45
        indicators.append({
            "title": "Raw IP Address Used as Hostname",
            "severity": "critical",
            "description": f"The URL points directly to an IP address ({hostname}) rather than a registered domain name.",
            "why_it_matters": "Legitimate public platforms virtually always use branded domain names. Direct IP addresses are commonly used by attackers to host short-lived phishing servers and evade domain-based blacklists."
        })

    # 3. Shortener Detection
    if hostname in URL_SHORTENERS:
        score += 25
        indicators.append({
            "title": "URL Shortener Service Detected",
            "severity": "medium",
            "description": f"The URL is disguised via shortener provider '{hostname}'.",
            "why_it_matters": "URL shorteners conceal the true destination domain, preventing users and basic email filters from inspecting the final landing page before clicking."
        })
        recommendations.append("Use a URL expander tool or check the destination preview before following the shortened link.")

    # 4. Excessive Length
    url_length = len(url)
    if url_length > 75:
        score += 25
        indicators.append({
            "title": f"Abnormally Long URL ({url_length} characters)",
            "severity": "medium",
            "description": "The overall URL is unusually long.",
            "why_it_matters": "Attackers construct lengthy URLs to push suspicious domain names out of visible mobile address bars and pad the query string with misleading parameters."
        })
    elif url_length > 54:
        score += 10
        indicators.append({
            "title": f"Extended URL Length ({url_length} characters)",
            "severity": "low",
            "description": "URL length exceeds typical homepage thresholds.",
            "why_it_matters": "Slightly longer than usual, often seen with extensive tracking tags or embedded redirects."
        })

    # 5. Obfuscation & Misleading Symbols
    if "@" in url:
        score += 40
        indicators.append({
            "title": "Embedded '@' Symbol in URL",
            "severity": "critical",
            "description": "The URL contains an '@' character.",
            "why_it_matters": "Browsers interpret everything preceding an '@' sign as user authentication credentials and route the browser to the domain following the '@'. This is a classic credential-masking trick."
        })

    if "//" in path:
        score += 25
        indicators.append({
            "title": "Double Slashes in Path ('//')",
            "severity": "high",
            "description": "Consecutive slashes appear inside the URL path.",
            "why_it_matters": "Multiple slashes often indicate open redirect abuse, where a legitimate site redirects visitors to an arbitrary external attacker server."
        })

    if "%" in url:
        score += 10
        indicators.append({
            "title": "Hex / URL-Encoded Characters Detected",
            "severity": "low",
            "description": "The URL contains percentage-encoded sequences.",
            "why_it_matters": "URL encoding is valid for special symbols, but heavy encoding is frequently used to obscure malicious payloads and evasion keywords."
        })

    # 6. Domain Structure, Subdomains & Hyphens
    domain_parts = hostname.split(".")
    if len(domain_parts) >= 2:
        tld = domain_parts[-1]
        registered_domain = ".".join(domain_parts[-2:])
        subdomain_count = len(domain_parts) - 2

        # Check high-abuse TLDs
        if tld in SUSPICIOUS_TLDS:
            score += 30
            indicators.append({
                "title": f"Suspicious Top-Level Domain (.{tld})",
                "severity": "high",
                "description": f"The domain uses the '.{tld}' extension, which has elevated abuse rates in phishing datasets.",
                "why_it_matters": "Low-cost and loosely regulated TLDs are statistically favored by cybercriminals for rapid, throwaway phishing operations."
            })

        # Deep subdomain nesting
        if subdomain_count >= 3:
            score += 25
            indicators.append({
                "title": f"Excessive Subdomain Depth ({subdomain_count} levels)",
                "severity": "high",
                "description": f"The host has multiple nested subdomains: '{hostname}'.",
                "why_it_matters": "Attackers construct multi-level subdomains (e.g. sbi.portal.verify.attacker.com) so the true base domain (attacker.com) is pushed to the far right and easily overlooked."
            })

        # Brand impersonation in subdomains
        for brand in TARGETED_BRANDS:
            if brand in hostname and brand not in registered_domain:
                score += 40
                indicators.append({
                    "title": f"Potential Brand Impersonation ('{brand}')",
                    "severity": "critical",
                    "description": f"The brand name '{brand}' appears in a subdomain or prefix, but the actual registered domain is '{registered_domain}'.",
                    "why_it_matters": "This is a primary phishing technique. The attacker owns '{registered_domain}', not '{brand}', but creates a fake subdomain to trick users into trusting the link."
                })
                break

    # Hyphen abuse in domain
    if hostname.count("-") >= 2:
        score += 20
        indicators.append({
            "title": f"Multiple Hyphens in Domain ({hostname.count('-')} found)",
            "severity": "medium",
            "description": "The domain name contains multiple hyphens.",
            "why_it_matters": "Legitimate major institutions rarely string together multiple hyphens (e.g. 'paypal-update-login-online.com'); this pattern is common in lookalike domains."
        })

    # Homograph / Punycode Check
    if "xn--" in hostname:
        score += 35
        indicators.append({
            "title": "Internationalized / Punycode Domain ('xn--')",
            "severity": "high",
            "description": "The hostname uses Punycode encoding representing non-ASCII characters.",
            "why_it_matters": "Homograph attacks replace Latin letters with visually identical Cyrillic or Greek glyphs (e.g., Cyrillic 'а' replacing Latin 'a') to mimic well-known websites."
        })

    # Non-standard port
    if parsed.port and parsed.port not in (80, 443):
        score += 25
        indicators.append({
            "title": f"Non-Standard Web Port (:{parsed.port})",
            "severity": "medium",
            "description": f"The connection specifies custom port {parsed.port} rather than standard port 80/443.",
            "why_it_matters": "Legitimate public financial and corporate portals run on standard web ports. Custom ports often host unauthorized rogue web servers."
        })

    # 7. Sensitive Phishing Keywords
    found_keywords = [kw for kw in PHISHING_KEYWORDS if kw in url.lower()]
    if found_keywords:
        kw_penalty = min(35, len(found_keywords) * 12)
        score += kw_penalty
        indicators.append({
            "title": f"High-Risk Keywords in URL ({', '.join(found_keywords[:4])})",
            "severity": "high" if len(found_keywords) > 1 else "medium",
            "description": f"The URL path or query contains sensitive security and financial terms: {', '.join(found_keywords)}.",
            "why_it_matters": "Attackers incorporate urgent terms like 'verify', 'kyc', 'login', or 'claim' to lure victims into credential-harvesting forms."
        })

    # Trusted domain bonus reduction
    if any(hostname == trusted or hostname.endswith("." + trusted) for trusted in TRUSTED_DOMAINS):
        # Even if trusted, don't reduce to 0 if there are critical flags like @ or //
        score = max(5, int(score * 0.2))
        indicators.append({
            "title": "Recognized Institutional Domain",
            "severity": "low",
            "description": f"The base domain '{hostname}' matches verified public infrastructure.",
            "why_it_matters": "Established domains have strong reputational standing, though subpages should still be reviewed for user-generated or compromised content."
        })

    # Recommendations based on score
    if score >= 75:
        recommendations.extend([
            "DO NOT click this link or submit any passwords, banking details, or OTPs.",
            "If received via email or SMS, mark the sender as spam and block.",
            "If you suspect your organization or bank is impersonated, visit their official portal by typing the address directly in your browser."
        ])
    elif score >= 50:
        recommendations.extend([
            "Exercise extreme caution before opening this website.",
            "Verify the exact registered domain name on whois lookup or official contact channels.",
            "Do not download any file, APK, or attachment prompted by this site."
        ])
    elif score >= 25:
        recommendations.extend([
            "Review the web address carefully before entering sensitive personal information.",
            "Check for official contact details and verify whether the source is expected.",
            "Ensure multi-factor authentication (MFA) is active on your important accounts."
        ])
    else:
        recommendations.extend([
            "No high-severity structural anomalies were detected on this address.",
            "Remember that attackers occasionally compromise legitimate sites; continue verifying page content.",
            "Never share one-time passwords (OTPs) or payment PINs regardless of site appearance."
        ])

    technical_details = {
        "scheme": scheme,
        "hostname": hostname,
        "path_length": len(path),
        "total_length": url_length,
        "subdomains_count": len(hostname.split(".")) - 2 if len(hostname.split(".")) >= 2 else 0,
        "has_ip_host": bool(re.match(ip_pattern, hostname)),
        "detected_keywords": found_keywords
    }

    return format_detection_result(
        module_type="url",
        raw_score=score,
        indicators=indicators,
        recommendations=recommendations,
        input_preview=url[:100],
        technical_details=technical_details
    )
