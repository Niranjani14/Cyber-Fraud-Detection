"""
UPI (Unified Payments Interface) Fraud Early Warning Detection Module.
Evaluates user-reported payment requests and warning signs against critical
threat patterns identified by NPCI, RBI, and cyber defense authorities:
- UPI PIN requested to 'receive' money or 'claim refund'
- Unprompted or unsolicited Collect Requests
- Screen-sharing / remote desktop application installation (AnyDesk, TeamViewer, etc.)
- Artificial urgency and intimidation
- Fake army officer / buyer scams (OLX, Quikr)
- 'Test Transaction' (verify account with ₹1 / ₹5) trap
"""

from typing import Dict, Any, List
from .risk_engine import format_detection_result


# High-risk remote access tools commonly used in financial screen-takeover scams
REMOTE_ACCESS_TOOLS = [
    "anydesk", "teamviewer", "rustdesk", "quicksupport", "zoho assist",
    "airdroid", "splashtop", "screenshare"
]


def analyze_upi_indicators(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Evaluates checklist signals and descriptive indicators for a UPI payment encounter.
    Input data dictionary contains boolean flags and optional free-text description.
    """
    score = 0
    indicators: List[Dict[str, str]] = []
    recommendations: List[str] = []

    # Extract boolean flags from request or form
    pin_to_receive = bool(data.get("pin_to_receive"))
    unexpected_collect = bool(data.get("unexpected_collect"))
    remote_app_requested = bool(data.get("remote_app_requested"))
    immediate_pressure = bool(data.get("immediate_pressure"))
    test_transaction = bool(data.get("test_transaction"))
    buyer_overpayment = bool(data.get("buyer_overpayment"))
    qr_to_receive = bool(data.get("qr_to_receive"))
    free_text = str(data.get("scenario_description") or "").lower()

    # Rule 1: CRITICAL - UPI PIN requested to receive money / claim refund
    if pin_to_receive or "enter pin to receive" in free_text or "pin for refund" in free_text:
        score += 55
        indicators.append({
            "title": "CRITICAL RULE VIOLATION: UPI PIN to Receive Money",
            "severity": "critical",
            "description": "The sender or caller claims you must enter your UPI PIN to receive money or get a refund.",
            "why_it_matters": "FUNDAMENTAL ARCHITECTURE RULE OF UPI: You NEVER enter your UPI PIN to receive money. A UPI PIN is solely a digital signature used to DEBIT funds from your account. The moment you enter your PIN, money will be immediately deducted from your bank balance."
        })

    # Rule 2: Remote Desktop / Screen Sharing Tools
    remote_tool_found = [t for t in REMOTE_ACCESS_TOOLS if t in free_text]
    if remote_app_requested or remote_tool_found:
        score += 50
        tool_name = remote_tool_found[0] if remote_tool_found else "Screen Sharing / Remote App"
        indicators.append({
            "title": f"Remote Access Tool Solicited ({tool_name})",
            "severity": "critical",
            "description": f"The caller requested you install or open a screen-sharing app like AnyDesk, TeamViewer, or QuickSupport.",
            "why_it_matters": "Remote desktop apps allow fraudsters to view your phone screen in real time, see your SMS OTPs, and control your device to siphon your funds without your physical interaction."
        })

    # Rule 3: QR Code to 'Receive' Money (Reverse QR Scam)
    if qr_to_receive or "scan qr to receive" in free_text or "qr code refund" in free_text:
        score += 40
        indicators.append({
            "title": "Reverse QR Code Scam Pattern",
            "severity": "critical",
            "description": "You were sent a QR code and instructed to scan it to receive money or a deposit.",
            "why_it_matters": "Scanning a QR code on PhonePe, Google Pay, or Paytm is an outbound action that transmits your money outward. Fraudsters trick sellers on OLX or Facebook Marketplace into scanning QR codes to steal money."
        })

    # Rule 4: Unexpected Collect Request
    if unexpected_collect or "collect request" in free_text:
        score += 30
        indicators.append({
            "title": "Unsolicited UPI Collect Request",
            "severity": "high",
            "description": "An unexpected notification popped up on your UPI app asking you to approve a payment or 'Pay' a specific amount.",
            "why_it_matters": "Scammers initiate unsolicited collect requests hoping users will hastily click 'Pay' and type their PIN thinking they are accepting incoming cash."
        })

    # Rule 5: Test Transaction (Verify with ₹1 or ₹5)
    if test_transaction or "transfer 1 rupee" in free_text or "test transaction" in free_text:
        score += 25
        indicators.append({
            "title": "Test Transaction / Micro-Deposit Verification Trap",
            "severity": "high",
            "description": "You were asked to send a small amount (e.g., ₹1 or ₹5) to 'activate' or 'verify' your account.",
            "why_it_matters": "Fraudsters use micro-transfers to verify your active VPA and build false psychological compliance before executing larger fraudulent transactions."
        })

    # Rule 6: Buyer Overpayment / Fake Screenshot Scam
    if buyer_overpayment or "sent extra money" in free_text or "refund extra" in free_text:
        score += 30
        indicators.append({
            "title": "Buyer Overpayment & Fake Transaction Screenshot",
            "severity": "high",
            "description": "The person claimed they 'accidentally paid you extra' or shared a fake payment screenshot and demanded an immediate refund.",
            "why_it_matters": "Scammers fabricate counterfeit SMS notifications or Photoshopped payment confirmations. In reality, no funds were ever credited to your bank account."
        })

    # Rule 7: Coercive Pressure & Threat
    if immediate_pressure or "urgent" in free_text or "threat" in free_text or "police" in free_text:
        score += 20
        indicators.append({
            "title": "High-Pressure Psychological Coercion",
            "severity": "medium",
            "description": "The other party is creating extreme urgency, shouting, or threatening account blockage/legal trouble if you do not pay immediately.",
            "why_it_matters": "Coercion is the hallmark of social engineering. Fraudsters know that if victims pause and consult a knowledgeable family member or their bank, the fraud will be exposed."
        })

    # Free text keyword checks if no flags were explicitly checked
    if score == 0 and free_text:
        score += 15
        indicators.append({
            "title": "Baseline Inquiry Assessment",
            "severity": "low",
            "description": "Scenario reviewed. No severe active fraud patterns were automatically matched in the text.",
            "why_it_matters": "Even if common keyword patterns were absent, always ensure you personally recognize the payee before authorizing any UPI transfer."
        })

    # Recommendations
    if score >= 75:
        recommendations.extend([
            "STOP IMMEDIATELY: DO NOT enter your UPI PIN. DO NOT approve the transaction.",
            "NEVER install AnyDesk, TeamViewer, or any app requested by the caller. If installed, disconnect Wi-Fi/mobile data and uninstall it immediately.",
            "Decline or ignore any Collect Request pending on your Google Pay / PhonePe / Paytm app.",
            "Block and report the sender's mobile number and UPI ID within your payment app.",
            "Report the fraud attempt to the National Cyber Crime Helpline: 1930 or online at cybercrime.gov.in."
        ])
    elif score >= 50:
        recommendations.extend([
            "Do NOT proceed with this payment request.",
            "Open your mobile banking app independently and check your actual account balance and statement directly.",
            "Never believe screenshots or SMS notifications without verifying your official bank statement.",
            "Remember: Scanning a QR code or entering a PIN is ALWAYS for paying out money, NEVER for receiving."
        ])
    elif score >= 25:
        recommendations.extend([
            "Double-check the beneficiary name displayed in your UPI app before completing payment.",
            "Do not accept unexpected collect requests from strangers.",
            "Keep your UPI PIN confidential; do not disclose it over phone calls or messages."
        ])
    else:
        recommendations.extend([
            "Standard UPI hygiene: Ensure you are transferring to a trusted individual or verified merchant.",
            "Check that the registered name matches the intended recipient.",
            "Remember that your UPI PIN is strictly for authorizing debits from your bank."
        ])

    preview = free_text[:80] if free_text else "Checklist Assessment"

    technical_details = {
        "pin_to_receive_flag": pin_to_receive,
        "unexpected_collect_flag": unexpected_collect,
        "remote_app_flag": remote_app_requested,
        "immediate_pressure_flag": immediate_pressure,
        "test_transaction_flag": test_transaction,
        "buyer_overpayment_flag": buyer_overpayment,
        "qr_to_receive_flag": qr_to_receive
    }

    return format_detection_result(
        module_type="upi",
        raw_score=score,
        indicators=indicators,
        recommendations=recommendations,
        input_preview=preview,
        technical_details=technical_details
    )
