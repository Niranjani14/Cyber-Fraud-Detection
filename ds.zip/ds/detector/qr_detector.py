"""
QR Code Fraud and Phishing (Quishing) Detection Module.
- Validates file format and file size limits
- Decodes QR matrix safely via OpenCV
- Parses decoded payload safely (no auto-execution or auto-navigation)
- Analyzes destination URLs using the URL detection engine
- Analyzes UPI payment URIs (upi://pay?...) for payment scams and payee impersonation
- Generates risk ratings, Quishing warnings, and defensive guidance
"""

import os
import re
from urllib.parse import urlparse, parse_qs
from typing import Dict, Any, List, Tuple
from .risk_engine import format_detection_result
from .url_detector import analyze_url

# Optional OpenCV import with fallback
try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB


def validate_image_file(file_path: str) -> Tuple[bool, str]:
    """Validate that the uploaded file exists, has a permitted extension, and is within size limits."""
    if not os.path.exists(file_path):
        return False, "Uploaded file does not exist on server."

    size = os.path.getsize(file_path)
    if size > MAX_FILE_SIZE:
        return False, f"File size exceeds maximum permitted limit (5 MB). Current size: {size / 1024 / 1024:.2f} MB"

    ext = os.path.splitext(file_path)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"Unsupported file format '{ext}'. Allowed formats: {', '.join(ALLOWED_EXTENSIONS)}"

    return True, "Valid"


def decode_qr_image(file_path: str) -> Tuple[bool, str, str]:
    """
    Decodes the QR code from image using OpenCV QRCodeDetector.
    Returns: (success_bool, decoded_text, error_message)
    """
    is_valid, msg = validate_image_file(file_path)
    if not is_valid:
        return False, "", msg

    if not CV2_AVAILABLE:
        return False, "", "OpenCV library is not yet loaded in environment. Please install opencv-python."

    try:
        # Load image via cv2
        image = cv2.imread(file_path)
        if image is None:
            return False, "", "Unable to read image. The file may be corrupted or unreadable."

        # Detect and decode QR Code
        detector = cv2.QRCodeDetector()
        decoded_text, points, _ = detector.detectAndDecode(image)

        if not decoded_text or points is None:
            # Try grayscale + threshold preprocessing to improve contrast
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            decoded_text, points, _ = detector.detectAndDecode(gray)

        if not decoded_text:
            # Try contrast enhancement
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            enhanced = clahe.apply(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY))
            decoded_text, points, _ = detector.detectAndDecode(enhanced)

        if not decoded_text:
            return False, "", "No valid QR code could be detected in this image. Ensure the QR code is clearly visible, focused, and uncropped."

        return True, decoded_text.strip(), ""
    except Exception as e:
        return False, "", f"QR decoding error: {str(e)}"


def analyze_decoded_payload(raw_payload: str) -> Dict[str, Any]:
    """
    Analyze the decoded string payload from a QR code:
    - Checks for URL vs UPI payment vs plain text
    - Assesses Quishing (QR phishing) and reverse payment scam risks
    """
    if not raw_payload:
        return format_detection_result(
            module_type="qr",
            raw_score=0,
            indicators=[],
            recommendations=["Upload a valid QR code image."],
            input_preview="No content decoded."
        )

    score = 0
    indicators: List[Dict[str, str]] = []
    recommendations: List[str] = []
    tech_details: Dict[str, Any] = {"raw_payload": raw_payload}

    # 1. Check for UPI Payment Scheme (upi://pay?...)
    if raw_payload.lower().startswith("upi://pay"):
        tech_details["payload_type"] = "UPI Payment Intent"
        parsed_upi = urlparse(raw_payload)
        query_params = parse_qs(parsed_upi.query)

        vpa = query_params.get("pa", [""])[0]
        payee_name = query_params.get("pn", [""])[0]
        amount = query_params.get("am", [""])[0]
        note = query_params.get("tn", [""])[0]

        tech_details["upi_vpa"] = vpa
        tech_details["payee_name"] = payee_name
        tech_details["amount"] = amount
        tech_details["transaction_note"] = note

        indicators.append({
            "title": "UPI Payment Trigger Decoded",
            "severity": "medium",
            "description": f"This QR code triggers a payment request to VPA '{vpa or 'Unknown'}' under name '{payee_name or 'Not Specified'}'.",
            "why_it_matters": "Scanning a payment QR code can immediately open your banking app with a payment request. Crucial rule: SCANNING A QR CODE IS STRICTLY FOR PAYING MONEY, NEVER FOR RECEIVING MONEY."
        })
        score += 35

        # Check for deceptive payee name
        deceptive_words = ["refund", "customer care", "helpdesk", "lottery", "prize", "cashback", "army", "olx", "officer"]
        if any(w in payee_name.lower() for w in deceptive_words) or any(w in note.lower() for w in deceptive_words):
            score += 35
            indicators.append({
                "title": f"Deceptive Payee Label / Lure ('{payee_name}')",
                "severity": "critical",
                "description": f"The merchant name or note contains suspicious authority keywords: '{payee_name}' / '{note}'.",
                "why_it_matters": "Fraudsters create personal VPAs with names like 'SBI Refund Desk' or 'Army Officer' to deceive victims into believing they are transacting with an institution."
            })

        # Fixed amount trap
        if amount:
            score += 15
            indicators.append({
                "title": f"Pre-configured Payment Amount (₹{amount})",
                "severity": "high",
                "description": f"The QR code has an enforced transaction amount of ₹{amount}.",
                "why_it_matters": "In reverse payment scams, attackers send a pre-filled QR code claiming 'scan to receive ₹{amount}', but scanning it actually initiates a transfer OUT of your account."
            })

        recommendations.extend([
            "CRITICAL: Never scan this QR code if someone promised to SEND or REFUND money to you.",
            "Remember: Entering your UPI PIN will DEBIT money from your bank account.",
            "Verify the exact Payee Virtual Payment Address (VPA) before authorizing any transaction in your UPI app.",
            "Do not enter your UPI PIN unless you intend to transfer your own funds."
        ])

    # 2. Check for URL / Web Link
    elif bool(re.match(r'^(https?://|www\.)', raw_payload, re.IGNORECASE)):
        tech_details["payload_type"] = "Web URL"
        url_result = analyze_url(raw_payload)
        base_url_score = url_result.get("risk_score", 0)

        # Quishing penalty: QR codes hide URLs from human eyes and perimeter email filters
        quishing_risk_addition = 15
        score = min(100, base_url_score + quishing_risk_addition)

        indicators.append({
            "title": "Quishing (QR Phishing) Threat Vector",
            "severity": "medium",
            "description": f"Decoded destination is a web address: {raw_payload[:60]}...",
            "why_it_matters": "Unlike standard hyperlinks where you can hover to see the URL, physical or digital QR codes mask the web destination until decoded. Cybercriminals use Quishing to bypass email security gateways and sticker over public transit/parking QR codes."
        })

        # Inherit URL indicators
        for ind in url_result.get("indicators", []):
            indicators.append(ind)

        # Recommendations
        recommendations.extend([
            "Do not automatically open or browse this URL on your phone.",
            "Check that the domain exactly matches the official company website before logging in.",
            "Inspect physical QR stickers in public locations to confirm they haven't been pasted over the legitimate sign."
        ])
        recommendations.extend(url_result.get("recommendations", []))

    # 3. Plain Text / Wi-Fi / Other payload
    else:
        tech_details["payload_type"] = "Plain Text / Generic Data"
        indicators.append({
            "title": "Decoded Plain Text Payload",
            "severity": "low",
            "description": f"Payload does not trigger automated web or payment handlers. Content length: {len(raw_payload)} characters.",
            "why_it_matters": "Plain text does not automatically route to external destinations, but verify that it does not instruct you to call a fraudulent number or visit an unlinked address."
        })
        recommendations.extend([
            "Review the decoded text carefully.",
            "Do not call unverified phone numbers or copy-paste unknown commands provided in the QR code."
        ])

    return format_detection_result(
        module_type="qr",
        raw_score=score,
        indicators=indicators,
        recommendations=recommendations,
        input_preview=raw_payload[:100],
        technical_details=tech_details
    )


def analyze_qr_image(file_path: str) -> Dict[str, Any]:
    """Full workflow: decodes QR image and runs payload threat analysis."""
    success, decoded_text, err = decode_qr_image(file_path)
    if not success:
        return format_detection_result(
            module_type="qr",
            raw_score=40,
            indicators=[{
                "title": "QR Decoding Unsuccessful",
                "severity": "medium",
                "description": err,
                "why_it_matters": "Images that cannot be decoded might be blurred, low resolution, or intentionally formatted to evade automated scanner inspection."
            }],
            recommendations=[
                "Upload a high-contrast, focused image of the QR code.",
                "Ensure the code is not cropped or warped.",
                "Never scan unreadable or damaged public QR codes with your personal mobile device."
            ],
            input_preview="Undecoded Image"
        )

    result = analyze_decoded_payload(decoded_text)
    result["decoded_text"] = decoded_text
    return result
