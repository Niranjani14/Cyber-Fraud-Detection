"""
Unified Risk Scoring and Explainability Engine.
Standardizes risk scoring across all detection modules:
- 0–24: Low (Green)
- 25–49: Medium (Yellow/Amber)
- 50–74: High (Orange)
- 75–100: Critical (Red)
Generates structured indicators, contextual rationales, and actionable next steps.
"""

from typing import List, Dict, Any


def compute_risk_tier(score: int or float) -> Dict[str, Any]:
    """
    Map raw numerical score (0-100) to standard Risk Category, CSS badge, and color tokens.
    """
    clamped_score = max(0, min(100, int(round(score))))

    if clamped_score <= 24:
        return {
            "category": "Low",
            "score": clamped_score,
            "badge_class": "badge-low",
            "color_hex": "#10b981",  # Emerald Green
            "text_class": "text-success",
            "severity_label": "Low Risk (Likely Safe / Routine)",
        }
    elif clamped_score <= 49:
        return {
            "category": "Medium",
            "score": clamped_score,
            "badge_class": "badge-medium",
            "color_hex": "#f59e0b",  # Amber/Yellow
            "text_class": "text-warning",
            "severity_label": "Medium Risk (Suspicious Indicators Present)",
        }
    elif clamped_score <= 74:
        return {
            "category": "High",
            "score": clamped_score,
            "badge_class": "badge-high",
            "color_hex": "#f97316",  # Bright Orange
            "text_class": "text-orange",
            "severity_label": "High Risk (Strong Fraud / Phishing Patterns)",
        }
    else:
        return {
            "category": "Critical",
            "score": clamped_score,
            "badge_class": "badge-critical",
            "color_hex": "#ef4444",  # Danger Red
            "text_class": "text-danger",
            "severity_label": "Critical Risk (Severe Scam / High Threat)",
        }


def format_detection_result(
    module_type: str,
    raw_score: int or float,
    indicators: List[Dict[str, str]],
    recommendations: List[str],
    input_preview: str,
    technical_details: Dict[str, Any] = None,
    disclaimer: str = None
) -> Dict[str, Any]:
    """
    Standardize output schema across all detection modules.
    
    indicators format: [
        {"title": "...", "severity": "low|medium|high|critical", "description": "...", "why_it_matters": "..."}
    ]
    """
    tier_info = compute_risk_tier(raw_score)

    if not disclaimer:
        disclaimer = (
            "Prototype Advisory Notice: This risk assessment is computed by heuristic analysis "
            "and machine learning pattern evaluation. It represents an estimated probability of fraud "
            "and does not constitute guaranteed legal proof or real-time banking verification. "
            "Always corroborate alerts through trusted official institutions."
        )

    # Determine a concise summary headline for the database
    if indicators:
        summary_reason = indicators[0].get("title", f"Assessed as {tier_info['category']} Risk")
        if len(indicators) > 1:
            summary_reason += f" (+{len(indicators)-1} other indicators)"
    else:
        summary_reason = f"No severe fraud indicators detected. Score: {tier_info['score']}/100"

    return {
        "success": True,
        "module": module_type,
        "input_preview": input_preview,
        "risk_score": tier_info["score"],
        "risk_category": tier_info["category"],
        "badge_class": tier_info["badge_class"],
        "color_hex": tier_info["color_hex"],
        "text_class": tier_info["text_class"],
        "severity_label": tier_info["severity_label"],
        "summary_reason": summary_reason,
        "indicators": indicators or [],
        "recommendations": recommendations or [],
        "technical_details": technical_details or {},
        "disclaimer": disclaimer,
    }
