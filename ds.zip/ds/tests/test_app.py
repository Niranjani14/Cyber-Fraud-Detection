"""
Integration and End-to-End Route Tests for Flask Application.
Tests page rendering, POST submissions, API routes, and history management.
"""

import unittest
import os
import sys
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import app
import database


class TestAppRoutes(unittest.TestCase):

    def setUp(self):
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
        self.client = app.test_client()
        database.init_db()

    def test_dashboard_page(self):
        """Test dashboard index loads successfully with status 200."""
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"AI Cyber Fraud Early Warning System", response.data)
        self.assertIn(b"Unified Cyber Threat Intelligence Dashboard", response.data)

    def test_api_stats(self):
        """Test API stats endpoint returns JSON metrics."""
        response = self.client.get("/api/stats")
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn("total_analyses", data)
        self.assertIn("category_counts", data)
        self.assertIn("module_counts", data)

    def test_url_analysis_route(self):
        """Test Phishing URL page GET and POST."""
        # GET
        get_res = self.client.get("/url")
        self.assertEqual(get_res.status_code, 200)
        self.assertIn(b"Phishing Website & URL Threat Inspection", get_res.data)

        # POST suspicious URL
        post_res = self.client.post("/url", data={"url": "http://185.220.101.5/sbi-verify.xyz"})
        self.assertEqual(post_res.status_code, 200)
        self.assertIn(b"Risk", post_res.data)
        self.assertIn(b"Detected Indicators", post_res.data)

    def test_message_analysis_route(self):
        """Test Scam Message page GET and POST."""
        get_res = self.client.get("/message")
        self.assertEqual(get_res.status_code, 200)

        # POST scam SMS
        post_res = self.client.post("/message", data={
            "message": "URGENT: Your electricity power will be cut tonight. Call 9876543210 immediately."
        })
        self.assertEqual(post_res.status_code, 200)
        self.assertIn(b"Risk", post_res.data)

    def test_news_analysis_route(self):
        """Test Fake News page GET and POST."""
        get_res = self.client.get("/news")
        self.assertEqual(get_res.status_code, 200)

        # POST sensational news
        post_res = self.client.post("/news", data={
            "news": "SHOCKING TRUTH! Secret miracle remedy doctors are desperately hiding from everyone!!!"
        })
        self.assertEqual(post_res.status_code, 200)
        self.assertIn(b"Verification Need", post_res.data)

    def test_qr_analysis_route(self):
        """Test QR analysis page with manual payload."""
        get_res = self.client.get("/qr")
        self.assertEqual(get_res.status_code, 200)

        # POST manual UPI QR payload
        post_res = self.client.post("/qr", data={
            "manual_payload": "upi://pay?pa=fake@ybl&pn=SBI+Refund&am=2000"
        })
        self.assertEqual(post_res.status_code, 200)
        self.assertIn(b"UPI Payment Trigger Decoded", post_res.data)

    def test_upi_analysis_route(self):
        """Test UPI warning analysis page."""
        get_res = self.client.get("/upi")
        self.assertEqual(get_res.status_code, 200)

        # POST UPI checklist
        post_res = self.client.post("/upi", data={
            "pin_to_receive": "on",
            "scenario_description": "Buyer asked me to enter UPI PIN to receive money on OLX"
        })
        self.assertEqual(post_res.status_code, 200)
        self.assertIn(b"CRITICAL RULE VIOLATION", post_res.data)

    def test_history_page_and_clear(self):
        """Test history log retrieval and clearing."""
        res = self.client.get("/history")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Analysis History & Security Audit Logs", res.data)

        # Test filter
        res_filter = self.client.get("/history?type=url")
        self.assertEqual(res_filter.status_code, 200)

    def test_awareness_page(self):
        """Test safety guide page renders."""
        res = self.client.get("/awareness")
        self.assertEqual(res.status_code, 200)

        self.assertIn(b"Golden Rules of UPI Payments", res.data)
        self.assertIn(b"1930", res.data)


if __name__ == "__main__":
    unittest.main()
