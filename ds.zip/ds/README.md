# AI Cyber Fraud Early Warning System
### *An AI-Powered Unified Cyber Fraud Detection Platform*

An intelligent, multi-vector cybersecurity early warning platform developed as an end-to-end full-stack prototype. It identifies, explains, and scores threats across URLs, phishing SMS/messages, disinformation, malicious QR codes, and UPI financial scams.

---

## 🛡️ Core Capabilities & Detection Engines

| Module | Threat Vector Analyzed | Detection Engine | Explainable Indicators |
| :--- | :--- | :--- | :--- |
| **Phishing URL Detection** | Malicious links, typosquatting, credential harvesters | Deep Lexical Parser & Heuristics | Raw IP host, subdomain depth, obfuscation (`@`, `//`), high-abuse TLDs, keyword lures |
| **Scam Message Detection** | SMS phishing (Smishing), bank impersonation, job lures | Scikit-learn TF-IDF + Naive Bayes & Rule Engine | Urgency coercion, OTP/PIN theft requests, rogue `.apk` downloads, advance-fee prize hooks |
| **Fake News Risk Analysis** | Sensationalism, unverified claims, emotional manipulation | Linguistic Heuristics & Sourcing Audit | Capitalization shouting, dramatic punctuation density, anonymous attribution, lack of citations |
| **QR Code Fraud Detection** | Quishing (QR Phishing) & Reverse UPI scams | OpenCV Image Matrix Decoder in Isolated Sandbox | Embedded link analysis, payment payload inspection (`upi://pay`), pre-filled amount traps |
| **UPI Fraud Warning Analysis** | Digital payment social engineering & remote takeover | NPCI Security Directive Evaluator | UPI PIN requested to 'receive' money, AnyDesk/TeamViewer remote apps, unprompted collect requests |

---

## 📊 Standardized Explainable Risk Scale

All platform detectors calibrate findings onto a unified 0–100 risk scoring index:

- **🟢 Low Risk (0 – 24):** Routine, benign patterns with standard security practices.
- **🟡 Medium Risk (25 – 49):** Anomalous indicators present; exercise heightened verification.
- **🟠 High Risk (50 – 74):** Strong fraud or phishing patterns identified; avoid clicking or authorizing.
- **🔴 Critical Risk (75 – 100):** Severe, unambiguous cyber theft or credential harvesting threat; stop immediately.

> **Advisory Disclaimer:** Scores represent the prototype's estimated risk calculation based on heuristic and ML pattern matching. They serve as an early advisory indicator and do not constitute guaranteed legal or real-time banking verification.

---

## 🛠️ Technology Stack

- **Frontend:** HTML5, CSS3, JavaScript (ES6+), Bootstrap 5.3, Chart.js 4.4, FontAwesome 6
- **Backend:** Python 3.12, Flask 3.1
- **Machine Learning & NLP:** Scikit-learn (TF-IDF Vectorizer + Multinomial Naive Bayes), Pandas, NumPy
- **Computer Vision / QR Decoding:** OpenCV (`cv2.QRCodeDetector`), Pillow (PIL)
- **Database:** Thread-safe SQLite 3 with parameterized queries and automated data sanitization
- **Testing:** Python `unittest` (26 automated unit and end-to-end integration tests)

---

## 🚀 Installation & Local Setup

### 1. Prerequisites
Ensure **Python 3.10+** is installed on your computer.

### 2. Install Dependencies
Open PowerShell or your preferred terminal in the project directory:

```powershell
pip install -r requirements.txt
```

### 3. Launch the Application
Run the Flask application:

```powershell
python app.py
```

The application will launch locally at:
```
http://127.0.0.1:5000/
```

Open `http://127.0.0.1:5000/` in any modern web browser (Chrome, Edge, Firefox, Brave).

---

## 🧪 Running the Automated Test Suite

The test suite covers:
- Boundary conditions for risk scores (0, 24, 25, 49, 50, 74, 75, 100)
- Legitimate vs. malicious URL patterns
- Scam SMS vs. benign banking alerts
- Sensationalist clickbait vs. verified press releases
- UPI PIN-to-receive violations and AnyDesk screen takeovers
- QR payload decoding and Quishing detection
- SQLite database logging and data sanitization
- Flask routes and REST API endpoints

To execute all 26 test cases:

```powershell
python -m unittest discover tests
```

---

## 📁 Project Structure

```
cyber_fraud_early_warning/
│
├── app.py                      # Main Flask application & REST API routes
├── database.py                 # SQLite database operations & history management
├── requirements.txt            # Python dependencies
├── README.md                   # Comprehensive project documentation
├── cyber_fraud.db              # SQLite database (auto-generated on startup)
│
├── detector/                   # Modular detection packages
│   ├── __init__.py             # Package exports
│   ├── risk_engine.py          # Unified 0-100 scoring & explanation generator
│   ├── url_detector.py         # URL & Phishing detection module
│   ├── message_detector.py     # TF-IDF ML & heuristic SMS/Message detector
│   ├── news_detector.py        # Sensationalism & source attribution analyzer
│   ├── qr_detector.py          # OpenCV QR decoder & Quishing analyzer
│   └── upi_detector.py         # UPI threat & NPCI directive evaluation
│
├── templates/                  # Jinja2 HTML templates
│   ├── base.html               # Base layout with navbar & 1930 helpline banner
│   ├── index.html              # Main intelligence dashboard & Chart.js charts
│   ├── url_analysis.html       # Phishing URL scanner
│   ├── message_analysis.html   # Scam message detector
│   ├── news_analysis.html      # Fake news risk evaluator
│   ├── qr_analysis.html        # QR code fraud scanner
│   ├── upi_analysis.html       # UPI warning analyzer
│   ├── history.html            # SQLite audit log with search & filters
│   └── awareness.html          # Defensive playbook & Golden Rules of UPI
│
├── static/                     # Frontend static assets
│   ├── css/
│   │   └── style.css           # Custom dark navy cybersecurity theme
│   └── js/
│       └── main.js             # Chart.js initialization & 1-click demo loaders
│
├── tests/                      # Automated test suite
│   ├── test_detectors.py       # Unit tests for all 5 threat detectors
│   └── test_app.py             # Integration & end-to-end Flask route tests
│
└── uploads/                    # Temporary QR image sandbox (auto-cleaned)
```

---

## 💡 1-Click Interactive College Project Demo

Every detector page includes **1-Click Quick Test Preset Chips** for effortless viva and college presentation demonstrations:

1. **Phishing URL:** Click `IP Phishing Host` or `@ Credential Masking` to see instant high/critical risk alerts with why-it-matters explanations.
2. **Scam Message:** Click `Fake Electricity Disconnect` or `Bank KYC .APK Lure` to see the dual AI NLP classification and heuristic red flags.
3. **Fake News:** Click `Sensational Miracle Cure` or `Official RBI Press Release` to compare sensationalist markers against verified citations.
4. **QR Code:** Click `Fake 'SBI Refund' UPI QR` to inspect how reverse payment traps are dissected without executing money debits.
5. **UPI Fraud:** Click `OLX Fake Army Buyer Trap` or `AnyDesk Screen Hijack` to observe NPCI safety rules in action.

---

## 🚨 Official Cyber Emergency Response

If you or someone you know has been targeted by a financial cyber fraud:
- **National Cyber Financial Fraud Helpline (India):** Dial **1930** immediately.
- **National Cyber Crime Reporting Portal:** File an FIR at [https://cybercrime.gov.in](https://cybercrime.gov.in).
- **Golden Hour Rule:** Reporting financial fraud within the first 2 hours enables banking authorities to freeze suspicious funds in recipient accounts before withdrawal.
