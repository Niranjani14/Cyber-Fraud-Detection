"""
Database module for AI Cyber Fraud Early Warning System.
Provides thread-safe SQLite operations for logging analysis history,
retrieving statistics, and managing historical fraud scans.
"""

import sqlite3
import json
import os
import re
from datetime import datetime

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cyber_fraud.db")


def get_db_connection():
    """Create and return a database connection with dictionary-like row access."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialize database tables with parameterized schema."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS analysis_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_type TEXT NOT NULL,
                target_summary TEXT NOT NULL,
                risk_score INTEGER NOT NULL,
                risk_category TEXT NOT NULL,
                summary_reason TEXT NOT NULL,
                details_json TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        # Create an index on timestamp and analysis_type for fast dashboard queries
        cursor.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_history_type_time 
            ON analysis_history (analysis_type, timestamp DESC)
            """
        )
        conn.commit()


def sanitize_summary(text: str, max_length: int = 120) -> str:
    """
    Sanitize input to avoid storing raw credentials, PINs, or sensitive private data.
    Truncates to max_length and redacts potential sensitive tokens.
    """
    if not text:
        return "N/A"
    
    clean = str(text).strip()
    # Mask potential 4-6 digit PINs or OTPs
    clean = re.sub(r'\b\d{4,6}\b', '[REDACTED_NUM]', clean)
    # Mask card numbers (16 digits)
    clean = re.sub(r'\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}\b', '[CARD_REDACTED]', clean)
    # Mask email passwords or query params
    clean = re.sub(r'password=[^&\s]+', 'password=[REDACTED]', clean, flags=re.IGNORECASE)
    
    if len(clean) > max_length:
        clean = clean[:max_length] + "..."
    return clean


def save_analysis(analysis_type: str, target_summary: str, risk_score: int, 
                  risk_category: str, summary_reason: str, details: dict = None) -> int:
    """
    Save an analysis scan result to the database using parameterized queries.
    """
    init_db()
    sanitized_target = sanitize_summary(target_summary)
    details_str = json.dumps(details) if details else "{}"

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO analysis_history 
            (analysis_type, target_summary, risk_score, risk_category, summary_reason, details_json, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
            """,
            (analysis_type, sanitized_target, int(risk_score), risk_category, summary_reason, details_str)
        )
        conn.commit()
        return cursor.lastrowid


def get_history(filter_type: str = None, search: str = None, limit: int = 100):
    """
    Retrieve analysis history with optional filtering by type or search term.
    """
    init_db()
    query = "SELECT * FROM analysis_history"
    params = []
    conditions = []

    if filter_type and filter_type.lower() != "all":
        conditions.append("analysis_type = ?")
        params.append(filter_type.lower())

    if search and search.strip():
        conditions.append("(target_summary LIKE ? OR summary_reason LIKE ?)")
        search_pattern = f"%{search.strip()}%"
        params.extend([search_pattern, search_pattern])

    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        results = []
        for r in rows:
            res = dict(r)
            try:
                res["details"] = json.loads(res.get("details_json") or "{}")
            except Exception:
                res["details"] = {}
            results.append(res)
        return results


def get_record_by_id(record_id: int):
    """Retrieve a single record by ID."""
    init_db()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM analysis_history WHERE id = ?", (record_id,))
        row = cursor.fetchone()
        if not row:
            return None
        res = dict(row)
        try:
            res["details"] = json.loads(res.get("details_json") or "{}")
        except Exception:
            res["details"] = {}
        return res


def delete_record(record_id: int) -> bool:
    """Delete a single analysis record by ID."""
    init_db()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM analysis_history WHERE id = ?", (record_id,))
        conn.commit()
        return cursor.rowcount > 0


def clear_all_history() -> bool:
    """Delete all records from analysis history."""
    init_db()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM analysis_history")
        conn.commit()
        return True


def get_statistics():
    """
    Generate aggregated statistics for the main dashboard:
    - total analyses
    - suspicious inputs (Medium, High, Critical)
    - high risk results (High, Critical)
    - risk distribution breakdown
    - detection module breakdown
    - recent analysis feed
    """
    init_db()
    with get_db_connection() as conn:
        cursor = conn.cursor()

        # Total counts
        cursor.execute("SELECT COUNT(*) FROM analysis_history")
        total_analyses = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM analysis_history WHERE risk_category IN ('Medium', 'High', 'Critical')"
        )
        suspicious_count = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM analysis_history WHERE risk_category IN ('High', 'Critical')"
        )
        high_risk_count = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM analysis_history WHERE risk_category = 'Low'"
        )
        low_risk_count = cursor.fetchone()[0]

        # Category breakdown
        category_counts = {
            "Low": low_risk_count,
            "Medium": 0,
            "High": 0,
            "Critical": 0
        }
        cursor.execute(
            "SELECT risk_category, COUNT(*) FROM analysis_history GROUP BY risk_category"
        )
        for cat, cnt in cursor.fetchall():
            if cat in category_counts:
                category_counts[cat] = cnt

        # Analysis type breakdown
        module_counts = {
            "url": 0,
            "message": 0,
            "news": 0,
            "qr": 0,
            "upi": 0
        }
        cursor.execute(
            "SELECT analysis_type, COUNT(*) FROM analysis_history GROUP BY analysis_type"
        )
        for mod, cnt in cursor.fetchall():
            module_counts[mod.lower()] = cnt

        # Recent 6 records
        cursor.execute(
            "SELECT * FROM analysis_history ORDER BY timestamp DESC LIMIT 6"
        )
        recent_rows = cursor.fetchall()
        recent_records = [dict(r) for r in recent_rows]

        return {
            "total_analyses": total_analyses,
            "suspicious_count": suspicious_count,
            "high_risk_count": high_risk_count,
            "low_risk_count": low_risk_count,
            "category_counts": category_counts,
            "module_counts": module_counts,
            "recent_records": recent_records
        }
